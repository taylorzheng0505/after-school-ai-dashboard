---
name: l2-weekly-report
description: 生成课后托管 L2 学习执行周看板。用户提出“生成L2周报/周看板/本周托管反馈”等请求时使用。优先读取指定周内的 daily-data.json，并通过结构化聚合、数据校验和固定渲染器生成统一HTML；只在JSON缺失时读取对应日期的日报HTML。汇总执行、客观核对、长期任务及截止日期/跨周待办、错题/听写与习惯，不扫描原始试卷或错题库，不做深层错因和能力诊断。
---

# L2 Weekly Report

Generate the current student's parent-facing L2 weekly dashboard through the v1.7 data pipeline.

## Workflow
1. Read `references/source-of-truth.md`, `references/interaction.md`, `references/output-rules.md`, `references/student-context.md`, `references/file-access-scope.md`, `references/weekly-data-schema.md`, and `references/visual-contract.md`.
2. Determine the requested week and collect only matching L2 `daily-data.json` files. Use same-date daily HTML only as a fallback when JSON is unavailable.
3. Run `python scripts/aggregate_weekly_data.py --report-type l2 <weekly-data.json> <daily-json...>` to create the preliminary weekly JSON, including inherited task deadlines and week-end carryover status.
4. Fill only the synthesis fields that require judgment, especially `habits`. Do not alter deterministic counts without evidence.
5. Run `python scripts/validate_weekly_data.py <weekly-data.json>` and fix until PASS.
6. Run `python scripts/render_weekly.py <weekly-data.json> <output.html>`.
7. Run `python scripts/validate_visual.py assets/template-reference.html <output.html> --report-type l2` and deliver only on PASS.

## Hard boundaries
- L2 is execution management only; no deep academic diagnosis.
- Do not rescan or re-crop raw worksheets.
- Every continuing/unresolved task must show its inherited deadline in the weekly report. Mark unresolved week-end tasks for next-week continuation; label overdue items explicitly.
- Never hand-edit the large final HTML or seed it from a demo-filled page.
- Never use cross-conversation memory as report facts.
