---
name: l2-weekly-report
description: 生成课后托管 L2 学习执行周看板。用户提出“生成L2周报/周看板/本周托管反馈”等请求时使用。只读取当前学生在指定周日期范围内的L2日报并自动汇总任务执行、长期任务进度、客观核对数据、错题/听写记录和学习习惯；不扫描原始试卷、独立错题库、月报或无关历史周。缺少预期到校日资料时最多定向追问一次，然后按固定机构模板生成家长可见HTML周报。严格保持L2边界，不做深层错因或能力诊断。
---

# L2 Weekly Report

Generate a parent-facing L2 weekly dashboard from the current student's daily reports for the requested week.

## Workflow
1. Read `references/source-of-truth.md`, `references/interaction.md`, `references/output-rules.md`, `references/student-context.md`, `references/file-access-scope.md`, and `references/visual-contract.md`.
2. Determine the requested reporting dates first. Filter the daily-report folder by date/file name, then read only matching L2 daily reports for the current student.
3. Do not scan raw homework/test folders, the standalone wrong-question library, monthly reports, or unrelated weeks.
4. Aggregate attendance, effective study time, task execution, long-cycle progress, objective subject data, wrong-question/dictation summaries and observable habits from the daily reports.
5. If an expected attendance date has no daily report, clarify whether it was absence/holiday or missing data. Do not broaden the search.
6. Ask at most one targeted follow-up for blocking gaps.
7. Generate the HTML from the locked institutional template and validate visual consistency.

## Production rendering
1. Clone `assets/template-reference.html` with `python scripts/clone_template.py assets/template-reference.html <output.html>`.
2. Edit only data-bearing content; never redesign the HTML.
3. Use evidence already carried in the daily reports when the weekly template displays examples. Do not re-crop raw worksheets.
4. Validate with `python scripts/validate_visual.py assets/template-reference.html <output.html>` and deliver only on `PASS`.

## Hard boundaries
- Stay within L2 scope: execution management only.
- Keep normal wrong questions and dictation errors separate.
- Do not produce deep academic diagnosis.
- Aggregate only the current student and requested week.
- Never use cross-conversation memory as report facts.
- Follow the strict weekly file-access allowlist in `references/file-access-scope.md`.
- Keep institution-wide visual consistency by preserving the bundled template structure and style.
