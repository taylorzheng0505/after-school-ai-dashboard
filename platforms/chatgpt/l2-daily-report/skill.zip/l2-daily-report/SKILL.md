---
name: l2-daily-report
description: 生成课后托管 L2 学习执行日看板。用户提出“生成L2日报/日看板/今天托管反馈”等请求时使用。读取当前学生稳定档案、最近一份历史日报中的未完成长期任务、督导明确指定的今日原始作业/试卷及本次批改结果，再索取当日时间、任务进展、订正、学习习惯与备注。整页作业中的已确认错题必须逐题裁剪后再进入固定机构HTML模板。最多定向追问一次。严格保持L2边界：只做学习执行管理，不输出错因诊断、专项教学建议或能力提升方案。
---

# L2 Daily Report

Generate a parent-facing L2 daily dashboard through a controlled intake workflow.

## Workflow
1. Read `references/source-of-truth.md`, `references/interaction.md`, `references/output-rules.md`, `references/student-context.md`, `references/file-access-scope.md`, `references/visual-contract.md`, and `references/cropping.md`.
2. Resolve stable profile fields from the current student's bound documents.
3. Read only the single most recent prior daily report before the target date and extract unfinished long-cycle/ongoing tasks for continuity. Do not inherit prior daily facts.
4. Use today's raw homework/test files or folders explicitly identified by the supervisor. Accept the grading result from any supervisor-provided source (text, screenshot, file, pasted output from another AI, or current conversation). Do not assume its location.
5. If a grading result already exists and clearly maps to today's source materials, reuse it; do not re-grade unless asked. If no grading result exists and the supervisor asks this AI to grade, grade the explicitly identified current-day materials first.
6. If critical inputs are incomplete, send the one-round intake prompt from `references/interaction.md`.
7. Parse the supplied facts and build the task checklist and wrong-question index.
8. For every confirmed wrong question whose source is a full worksheet/page, **mandatory: create a per-question evidence crop** following `references/cropping.md` before generating the HTML.
9. Run completeness checks. If status is RED, ask one targeted follow-up containing all blocking gaps.
10. Generate one self-contained HTML file by starting from `assets/template-reference.html` as the locked base template.

## Production rendering
1. Read `references/visual-contract.md`.
2. Clone `assets/template-reference.html` with `python scripts/clone_template.py assets/template-reference.html <output.html>`.
3. Edit only data-bearing content; never redesign the HTML.
4. Use the per-question crops created from today's source pages. Do not embed a whole worksheet page as the normal substitute for an identified wrong question.
5. Validate with `python scripts/validate_visual.py assets/template-reference.html <output.html>` and deliver only on `PASS`.

## Hard boundaries
- Stay within L2 scope: execution management only.
- Do not diagnose why a question was wrong or output ability/remediation judgments.
- Preserve original visual evidence; OCR/transcription may assist indexing but must not replace it.
- Describe learning habits with observable behavior, not vague praise.
- Never use cross-conversation memory as report facts.
- Apply Fresh-State to all date-specific facts while preserving continuity only for unfinished long-cycle tasks from the single latest prior daily report.
- Do not recursively scan weekly/monthly/history/wrong-question folders. Follow `references/file-access-scope.md`.
- Per-question cropping is mandatory for identified wrong questions from full-page source materials. Whole-page evidence is exception-only after conservative crop failure.
- Keep institution-wide visual consistency by preserving the bundled template structure and style.
