---
name: l3-daily-report
description: 生成课后托管 L3 学业管理日看板。用户提出“生成L3日报/日看板/今天L3反馈”等请求时使用。完整继承L2执行层，读取当前学生稳定档案、最近一份历史日报中的未完成长期任务、督导明确指定的今日原始作业/试卷及本次批改结果；整页作业中的已确认错题必须逐题裁剪，再基于可用证据结构化记录题型、能力/知识点、错误表现、错因与订正状态，并记录当天Math/English专项辅导。最多定向追问一次，按固定机构HTML模板生成。
---

# L3 Daily Report

Generate an L3 daily dashboard by fully inheriting the L2 execution layer and adding L3 academic structure.

## Workflow
1. Read `references/source-of-truth.md`, `references/interaction.md`, `references/output-rules.md`, `references/student-context.md`, `references/file-access-scope.md`, `references/visual-contract.md`, and `references/cropping.md`.
2. Resolve stable profile fields from the current student's bound documents.
3. Read only the single most recent prior daily report before the target date and extract unfinished long-cycle/ongoing tasks for continuity. Do not inherit prior daily facts.
4. Use today's raw homework/test files or folders explicitly identified by the supervisor. Accept the grading result from any supervisor-provided source; do not assume it came from this conversation or this AI.
5. If a grading result already exists and maps to today's materials, reuse it; do not re-grade unless asked. If absent and the supervisor asks this AI to grade, grade the explicitly identified current-day materials first.
6. If critical inputs are incomplete, use the one-round intake prompt.
7. Build the wrong-question index. For every confirmed wrong question sourced from a full page, **mandatory: create a per-question evidence crop** before HTML generation.
8. Structure each wrong question into question type, involved ability/knowledge point, observed error manifestation, cause and correction status using available evidence. Do not overstate certainty.
9. Add today's Math/English focused-tutoring status and teacher feedback.
10. Run completeness checks and ask at most one targeted follow-up for blocking gaps.
11. Generate one self-contained HTML file from the locked institutional template.

## Production rendering
1. Clone `assets/template-reference.html` with `python scripts/clone_template.py assets/template-reference.html <output.html>`.
2. Edit only data-bearing content; never redesign the HTML.
3. Use per-question crops in wrong-question evidence cards. Whole-page worksheet images are not the normal output for identified wrong questions.
4. Validate with `python scripts/validate_visual.py assets/template-reference.html <output.html>` and deliver only on `PASS`.

## Hard boundaries
- L3 must never lose L2 base fields such as arrival/departure, effective study time, task checklist and habit observation.
- Parent-facing output shows the final integrated wrong-question analysis; do not expose “student said / teacher said / AI said”.
- Do not turn one error into a stable ability diagnosis. If evidence is insufficient, say “暂无法判断/需继续观察”.
- Never use cross-conversation memory as report facts.
- Apply Fresh-State to date-specific facts while preserving continuity only for unfinished long-cycle tasks from the single latest prior daily report.
- Do not recursively scan weekly/monthly/history/wrong-question folders. Follow `references/file-access-scope.md`.
- Per-question cropping is mandatory for identified wrong questions from full-page source materials. Whole-page evidence is exception-only after conservative crop failure.
- Keep institution-wide visual consistency by preserving the bundled template structure and style.
