---
name: l3-monthly-report
description: 生成课后托管 L3 学业管理月看板。用户提出“生成L3月报/月看板/月度家长沟通报告”等请求时使用。只读取当前学生在指定月份内的L3日报，另读取督导明确提供/定位的本月月测、路线进度，以及需要环比时的上月月报；从日报汇总任务执行、错题与听写趋势、专项辅导、学习习惯和能力问题图。不扫描原始试卷、独立错题库或无关月份，也不重新裁剪原始作业。最多定向追问一次，然后按固定机构模板生成家长可见HTML月报。
---

# L3 Monthly Report

Generate a parent-facing L3 monthly dashboard from the current student's daily reports for the requested month plus explicitly required monthly sources.

## Workflow
1. Read `references/source-of-truth.md`, `references/interaction.md`, `references/output-rules.md`, `references/student-context.md`, `references/file-access-scope.md`, and `references/visual-contract.md`.
2. Determine the target month first. Filter the daily-report folder by date/file name, then read only matching L3 daily reports for the current student.
3. Read the current month's mock/assessment data and route-management update only from explicitly supplied information or explicitly identified files/paths.
4. Read the immediately previous monthly report only when month-over-month comparison is required.
5. Do not scan raw homework/test folders, standalone wrong-question libraries, unrelated months, or arbitrary neighboring folders. Do not re-crop original worksheets.
6. Aggregate monthly execution, wrong-question/dictation trends, focused-tutoring delivery, habits, ability/problem map and intervention effects from the daily reports and monthly sources.
7. Ask at most one targeted follow-up for blocking missing mock/route/source data instead of broadening the search.
8. Generate from the locked institutional template and validate visual consistency.

## Hard boundaries
- Base monthly conclusions on accumulated evidence, not a single isolated error.
- If evidence is insufficient, use “暂无法判断/需继续观察”.
- Keep route content aligned with the student's current route.
- Use the previous monthly report only for explicit comparison, never as current-month fact.
- Never use cross-conversation memory as report facts.
- Follow the strict monthly file-access allowlist in `references/file-access-scope.md`.
- Keep institution-wide visual consistency by preserving the bundled template structure and style.
