---
name: l3-weekly-report
description: 生成课后托管 L3 学业管理周看板。用户提出“生成L3周报/周看板/本周L3反馈”等请求时使用。优先读取指定周内的 daily-data.json，通过结构化聚合、数据校验和固定渲染器生成统一HTML；只在JSON缺失时读取对应日报HTML。汇总执行、长期任务及截止日期/跨周待办、结构化错题、重复信号、学习习惯与专项辅导，强校验Math 2/2、English 2/2，不扫描原始试卷/错题库、不重新裁图、不使用课次结转或余额逻辑。
---

# L3 Weekly Report

Generate the current student's parent-facing L3 weekly dashboard through the v1.7 data pipeline.

## Workflow
1. Read `references/source-of-truth.md`, `references/interaction.md`, `references/output-rules.md`, `references/student-context.md`, `references/file-access-scope.md`, `references/weekly-data-schema.md`, and `references/visual-contract.md`.
2. Determine the requested week and collect only matching L3 `daily-data.json` files. Use same-date daily HTML only as a fallback when JSON is unavailable.
3. Run `python scripts/aggregate_weekly_data.py --report-type l3 <weekly-data.json> <daily-json...>` to compute deterministic totals, collect structured evidence, and inherit task deadlines/week-end carryover status.
4. Using `_analysis_inputs`, synthesize `habits`, `recurring_signals`, `next_week_focus`, and tutoring focus text. Do not change calculated totals without evidence. A recurring signal requires occurrence >= 2.
5. Validate Math required/delivered 2/2 and English 2/2. If a count is short and record status is ambiguous, ask one targeted follow-up.
6. Run `python scripts/validate_weekly_data.py <weekly-data.json>` and fix until PASS.
7. Run `python scripts/render_weekly.py <weekly-data.json> <output.html>`.
8. Run `python scripts/validate_visual.py assets/template-reference.html <output.html> --report-type l3` and deliver only on PASS.

## Hard boundaries
- Single errors are not stable weekly ability problems.
- Do not rescan or re-crop raw worksheets.
- Do not use tutoring balance/carryover concepts.
- Every continuing/unresolved task must show its inherited deadline in the weekly report. Mark unresolved week-end tasks for next-week continuation; label overdue items explicitly.
- Never hand-edit the final HTML or seed it from demo-filled HTML.
- Never use cross-conversation memory as report facts.
