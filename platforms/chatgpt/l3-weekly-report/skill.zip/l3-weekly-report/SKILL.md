---
name: l3-weekly-report
description: 生成课后托管 L3 学业管理周看板。用户提出“生成L3周报/周看板/本周L3反馈”等请求时使用。只读取当前学生在指定周日期范围内的L3日报并自动汇总执行数据、错题重复信号、学习习惯与专项辅导；校验Math 2/2、English 2/2，不做课次结转。默认不扫描原始试卷、独立错题库、月报或无关历史周，也不重新裁剪原始作业。最多定向追问一次，然后按固定机构模板生成家长可见HTML周报。
---

# L3 Weekly Report

Generate a parent-facing L3 weekly dashboard from the current student's L3 daily reports for the requested week.

## Workflow
1. Read `references/source-of-truth.md`, `references/interaction.md`, `references/output-rules.md`, `references/student-context.md`, `references/file-access-scope.md`, and `references/visual-contract.md`.
2. Determine the requested reporting dates first. Filter by date/file name and read only matching L3 daily reports for the current student.
3. Do not scan raw homework/test folders, the standalone wrong-question library, monthly reports, or unrelated weeks. Do not re-crop original worksheets.
4. Aggregate execution facts, structured wrong-question records, dictation summaries, focused-tutoring attendance and process/habit observations from the daily reports.
5. Produce cautious weekly pattern analysis from repeated daily evidence.
6. Validate the weekly tutoring rule: Math 2 sessions + English 2 sessions. No carryover/balance language.
7. If a session is missing from daily reports, accept explicit supplemental teacher/supervisor feedback; otherwise ask one targeted follow-up.
8. Generate from the locked institutional template and validate visual consistency.

## Hard boundaries
- Keep all weekly facts consistent with linked daily reports.
- Do not overstate low-frequency signals.
- Keep normal wrong questions and dictation errors separate.
- Do not present carryover or accumulated-balance language.
- Aggregate only the current student and requested week.
- Never use cross-conversation memory as report facts.
- Follow the strict weekly file-access allowlist in `references/file-access-scope.md`.
- Keep institution-wide visual consistency by preserving the bundled template structure and style.
